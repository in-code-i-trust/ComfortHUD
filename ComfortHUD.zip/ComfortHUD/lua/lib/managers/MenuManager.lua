local key = ModPath .. '	' .. RequiredScript
if _G[key] then return else _G[key] = true end

_G.ComfortHUD = _G.ComfortHUD or {}
ComfortHUD.settings = {
	silence_others_suspicion = true,
}
ComfortHUD.path = ModPath
ComfortHUD.data_path = SavePath .. 'ComfortHUD.txt'

function ComfortHUD:load_settings()
	local file = io.open(ComfortHUD.data_path, 'r')
	if file then
		for k, v in pairs(json.decode(file:read('*all')) or {}) do
			if type(v) == "string" then
				log("[ComfortHUD]load_settings: " .. k .. "=" .. v)
			else
				log("[ComfortHUD]load_settings: " .. k .. "=" .. tostring(v))
			end
			ComfortHUD.settings[k] = v
		end
		file:close()
	end
end

function ComfortHUD:save_settings()
	local file = io.open(ComfortHUD.data_path, 'w+')
	if file then
		local out = {}
		for k, v in pairs(ComfortHUD.settings) do
			if type(v) == "string" then
				log("[ComfortHUD]save_setting: " .. k .. "=" .. v)
			else
				log("[ComfortHUD]save_setting: " .. k .. "=" .. tostring(v))
			end
			out[k] = v
		end
		file:write(json.encode(out))
		file:close()
	end
end


Hooks:Add('LocalizationManagerPostInit', 'LocalizationManagerPostInit_ComfortHUD', function(loc)
	local language_filename

	for _, filename in pairs(file.GetFiles(ComfortHUD.path .. 'loc/')) do
		local str = filename:match('^(.*).txt$')
		if str and Idstring(str) and Idstring(str):key() == SystemInfo:language():key() then
			language_filename = filename
			break
		end
	end

	if language_filename then
		loc:load_localization_file(ComfortHUD.path .. 'loc/' .. language_filename)
	end
	loc:load_localization_file(ComfortHUD.path .. 'loc/english.txt', false)
end)

Hooks:Add('MenuManagerInitialize', 'MenuManagerInitialize_ComfortHUD', function(menu_manager)
	function MenuCallbackHandler:ComfortHUDHub(item)
		log("[ComfortHUD]Value update")
		ComfortHUD.settings[item:name()] = item:value()
	end

	function MenuCallbackHandler:ComfortHUDToggleHub(item)
		log("[ComfortHUD]Toggle update")
		ComfortHUD.settings[item:name()] = item:value() == 'on'
	end

	function MenuCallbackHandler:ComfortHUDChangedFocus(focus)
		log("[ComfortHUD]ComfortHUDChangedFocus")
		if not focus then
			ComfortHUD:save_settings()
		end
	end

	log("[ComfortHUD]MenuHelper:LoadFromJsonFile")
	MenuHelper:LoadFromJsonFile(ComfortHUD.path .. 'menu/options.txt', ComfortHUD, ComfortHUD.settings)

	Hooks:Add('MenuManagerBuildCustomMenus', 'MenuManagerBuildCustomMenus_ComfortHUD', function(menu_manager, nodes)
		nodes.cmfrthd_options_menu:parameters().modifier = {ComfortHUDCreator.modify_node}
	end)
end)

ComfortHUDCreator = ComfortHUDCreator or class()
function ComfortHUDCreator.modify_node(node)
	local old_items = node:items()

	node:clean_items()

	for _ = 1, 1 do
		node:add_item(table.remove(old_items, 1))
	end

	managers.menu:add_back_button(node)

	return node
end

ComfortHUD.load_settings()