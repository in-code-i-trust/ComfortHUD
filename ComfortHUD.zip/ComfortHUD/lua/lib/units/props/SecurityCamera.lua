
local key = ModPath .. '	' .. RequiredScript
if _G[key] then return else _G[key] = true end

local _set_suspicion_sound_original = SecurityCamera._set_suspicion_sound

--[[
function SecurityCamera:_set_suspicion_sound(suspicion_level)
	if self._suspicion_sound_lvl == suspicion_level then
		return
	end

	if not self._suspicion_sound then
		self._suspicion_sound = self._unit:sound_source():post_event("camera_suspicious_signal")
		self._suspicion_sound_lvl = 0
	end

	local pitch = self._suspicion_sound_lvl <= suspicion_level and 1 or 0.6
	self._suspicion_sound_lvl = suspicion_level

	self._unit:sound_source():set_rtpc("camera_suspicion_level_pitch", pitch)
	self._unit:sound_source():set_rtpc("camera_suspicion_level", suspicion_level)

	if Network:is_server() then
		local suspicion_lvl_sync = math.clamp(math.ceil(suspicion_level * 6), 1, 6)

		if suspicion_lvl_sync ~= self._suspicion_lvl_sync then
			self._suspicion_lvl_sync = suspicion_lvl_sync
			local event_id = self._NET_EVENTS["suspicion_" .. tostring(suspicion_lvl_sync)]

			self:_send_net_event(event_id)
		end
	end
end
]]

function SecurityCamera:_set_suspicion_sound(suspicion_level)
    if Network:is_server() then
        -- Because Server controlls everyone's suspicous sound, 
        -- Server should not ignore sound event.
		_set_suspicion_sound_original(self, suspicion_level)
        return
    end

    if suspicion_level == 0 then
		_set_suspicion_sound_original(self, suspicion_level)
        return
    end

    local suspicion_lvl_sync = math.clamp(math.ceil(suspicion_level * 6), 1, 6)
    local event_id = self._NET_EVENTS["suspicion_" .. tostring(suspicion_lvl_sync)]

	local net_events = self._NET_EVENTS

	if not (net_events.suspicion_1 <= event_id and event_id <= net_events.suspicion_6) then
		_set_suspicion_sound_original(self, suspicion_level)
        return
    end

	local is_sound_enabled = true

	if ComfortHUD.settings.silence_others_suspicion then
        -- Check distance
        local player = managers.player:player_unit()
        local cam = self._unit
        local dist = mvector3.distance(player:position(), cam:position())

        -- log("[ComfortHUD]distance is " .. tostring(dist) .. "cm")
        
        if dist > 1500 then
            is_sound_enabled = false
        end
	end

	if is_sound_enabled == true then
		_set_suspicion_sound_original(self, suspicion_level)
	end
end

--[[
local sync_net_event_original = SecurityCamera.sync_net_event

function SecurityCamera:sync_net_event(event_id)
	local net_events = self._NET_EVENTS

	if not (net_events.suspicion_1 <= event_id and event_id <= net_events.suspicion_6) then
		sync_net_event_original(self, event_id)
        return
    end

	local is_sync_net_event = true

	if ComfortHUD.settings.silence_others_suspicion then
        -- Check distance
        local player = managers.player:player_unit()
        local cam = self.unit
        local dist = mvector3.distance(player:position(), cam:position())

        log("[ComfortHUD]distance is " .. tostring(dist) .. "cm")
        
        if dist < 1000 then
            is_sync_net_event = false
        end
	end

	if is_sync_net_event == true then
		sync_net_event_original(self, event_id)
	end
end
]]