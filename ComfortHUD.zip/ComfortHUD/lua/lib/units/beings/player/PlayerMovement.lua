
local key = ModPath .. '	' .. RequiredScript
if _G[key] then return else _G[key] = true end

local _feed_suspicion_to_hud_original = PlayerMovement._feed_suspicion_to_hud

function PlayerMovement:_feed_suspicion_to_hud()
	local show_suspicion_warning_hud = true

	if ComfortHUD.settings.silence_others_suspicion then
		-- Check whether this unit is local player or not.
		local suspicion_is_self = false

		local suspicion_peer = managers.network:session():peer_by_unit(self._unit)
		if suspicion_peer then
			if suspicion_peer:id() == managers.network:session():local_peer():id() then
				suspicion_is_self = true
			end
		else
			-- Offline mode?
			suspicion_is_self = true
		end

		show_suspicion_warning_hud = suspicion_is_self
	end

	if show_suspicion_warning_hud == true then
		_feed_suspicion_to_hud_original(self)
	end
end
